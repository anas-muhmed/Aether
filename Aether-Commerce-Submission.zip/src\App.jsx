import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, Check, Globe2, Headphones, PackageCheck, ShieldCheck, Sparkles, Star } from 'lucide-react'
import { Navbar } from './components/Navbar'
import { ProductCard } from './components/ProductCard'
import { Assistant } from './components/Assistant'
import { categories, products, testimonials } from './data'

const reveal = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: .65, ease: [0.22, 1, 0.36, 1] },
}

function SectionHeading({ eyebrow, title, action }) {
  return (
    <motion.div {...reveal} className="mb-9 flex items-end justify-between gap-5 sm:mb-12">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="section-title">{title}</h2>
      </div>
      {action && <a href="#featured" className="hidden items-center gap-2 text-sm font-semibold sm:flex">{action} <ArrowRight size={16} /></a>}
    </motion.div>
  )
}

function useCountdown() {
  const [seconds, setSeconds] = useState(8 * 3600 + 42 * 60 + 16)
  useEffect(() => {
    const timer = setInterval(() => setSeconds((s) => s > 0 ? s - 1 : 24 * 3600), 1000)
    return () => clearInterval(timer)
  }, [])
  return [
    Math.floor(seconds / 3600),
    Math.floor((seconds % 3600) / 60),
    seconds % 60,
  ].map((n) => String(n).padStart(2, '0'))
}

export default function App() {
  const [dark, setDark] = useState(() => localStorage.getItem('aether-theme') === 'dark')
  const [cartCount, setCartCount] = useState(0)
  const [toast, setToast] = useState('')
  const [subscribed, setSubscribed] = useState(false)
  const [recent, setRecent] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aether-recent') || '[]') } catch { return [] }
  })
  const [hours, minutes, seconds] = useCountdown()

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
    localStorage.setItem('aether-theme', dark ? 'dark' : 'light')
  }, [dark])

  const addToCart = (product) => {
    setCartCount((count) => count + 1)
    setToast(`${product.name} added to your bag`)
    setTimeout(() => setToast(''), 2500)
  }

  const showNotice = (message) => {
    setToast(message)
    setTimeout(() => setToast(''), 2500)
  }

  const viewProduct = (product) => {
    setRecent((current) => {
      const next = [product, ...current.filter((item) => item.id !== product.id)].slice(0, 3)
      localStorage.setItem('aether-recent', JSON.stringify(next))
      return next
    })
  }

  const featureProducts = useMemo(() => products.slice(0, 6), [])

  return (
    <div className="min-h-screen overflow-hidden bg-paper text-ink transition-colors duration-300 dark:bg-[#0d0e11] dark:text-white">
      <a href="#main-content" className="fixed left-4 top-3 z-[100] -translate-y-20 rounded-full bg-ink px-4 py-2 text-sm font-bold text-white transition focus:translate-y-0 dark:bg-white dark:text-ink">
        Skip to content
      </a>
      <Navbar dark={dark} onTheme={() => setDark(!dark)} cartCount={cartCount} onNotice={showNotice} />

      <main id="main-content">
        <section className="relative px-4 pb-16 pt-28 sm:px-6 sm:pb-24 sm:pt-32">
          <div className="pointer-events-none absolute left-[-10%] top-16 size-[38rem] rounded-full bg-[#cad6ff]/35 blur-3xl dark:bg-[#263e9d]/20" />
          <div className="relative mx-auto grid min-h-[680px] max-w-7xl overflow-hidden rounded-[2rem] bg-[#101522] text-white md:grid-cols-[.9fr_1.1fr] lg:min-h-[720px] lg:rounded-[2.75rem]">
            <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: .8 }} className="relative z-10 flex flex-col justify-center px-6 pb-8 pt-12 sm:px-12 md:py-16 lg:px-16">
              <div className="mb-7 flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/8 px-3 py-2 text-xs font-semibold backdrop-blur">
                <Sparkles size={14} className="text-acid" /> The new Aether Arc One
              </div>
              <h1 className="max-w-xl font-display text-[3.25rem] font-semibold leading-[.95] tracking-[-.065em] sm:text-6xl lg:text-[5.25rem]">
                Sound,<br />reimagined.
              </h1>
              <p className="mt-6 max-w-md text-base leading-relaxed text-white/60 sm:text-lg">
                Spatial clarity. All-day comfort. A listening experience engineered to disappear.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <a href="#featured" className="button-primary bg-white text-ink hover:bg-acid">Shop Arc One <ArrowRight size={17} /></a>
                <a href="#why-aether" className="button-secondary border-white/20 bg-white/5 text-white hover:bg-white/10">Explore the story</a>
              </div>
              <div className="mt-12 flex items-center gap-6 text-sm text-white/55">
                <span><strong className="block text-lg text-white">40 hr</strong> battery</span>
                <span className="h-9 w-px bg-white/15" />
                <span><strong className="block text-lg text-white">218 g</strong> weight</span>
                <span className="h-9 w-px bg-white/15" />
                <span><strong className="block text-lg text-white">Hi-Res</strong> wireless</span>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, scale: 1.08 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.1, ease: 'easeOut' }} className="relative min-h-[340px] overflow-hidden md:min-h-full">
              <img src="/hero-aether-arc.webp" alt="Aether Arc One silver over-ear headphones" width="1536" height="1024" fetchPriority="high" className="absolute inset-0 h-full w-full object-cover object-center md:object-[58%_center]" />
              <div className="absolute inset-0 bg-gradient-to-b from-[#101522] via-transparent to-[#101522]/40 md:bg-gradient-to-r md:from-[#101522] md:via-transparent md:to-transparent" />
              <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }} className="absolute bottom-6 right-6 rounded-2xl border border-white/15 bg-black/25 px-4 py-3 backdrop-blur-xl sm:bottom-10 sm:right-10">
                <span className="text-xs text-white/55">Starting at</span>
                <strong className="block font-display text-xl">$349</strong>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <section id="collections" className="section-shell">
          <SectionHeading eyebrow="Find your orbit" title="Trending categories" action="View all categories" />
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-5">
            {categories.map((category, i) => (
              <motion.a {...reveal} transition={{ ...reveal.transition, delay: i * .08 }} href="#featured" key={category.name} className={`${category.color} group relative flex min-h-52 flex-col justify-between overflow-hidden rounded-[1.75rem] p-5 text-ink sm:min-h-64 sm:p-7`}>
                <span className="text-xs font-semibold uppercase tracking-wider text-black/50">{category.count}</span>
                <span className="absolute right-[-8%] top-[18%] text-[7rem] font-light opacity-20 transition duration-500 group-hover:rotate-12 group-hover:scale-110 sm:text-[9rem]">{category.icon}</span>
                <div className="relative flex items-end justify-between">
                  <h3 className="font-display text-xl font-bold sm:text-2xl">{category.name}</h3>
                  <span className="grid size-9 place-items-center rounded-full bg-ink text-white transition group-hover:translate-x-1"><ArrowRight size={16} /></span>
                </div>
              </motion.a>
            ))}
          </div>
        </section>

        <section id="featured" className="section-shell">
          <SectionHeading eyebrow="Objects of desire" title="The Aether edit" action="Shop all products" />
          <div className="grid grid-cols-2 gap-x-3 gap-y-10 lg:grid-cols-3 lg:gap-x-6 lg:gap-y-14">
            {featureProducts.map((product) => <ProductCard key={product.id} product={product} onView={viewProduct} onAdd={addToCart} />)}
          </div>
        </section>

        <section className="section-shell">
          <motion.div {...reveal} className="relative overflow-hidden rounded-[2rem] bg-[#d9ff64] p-6 text-ink sm:p-10 lg:grid lg:grid-cols-[1fr_.85fr] lg:p-14">
            <div className="relative z-10">
              <p className="eyebrow text-black/50">One day only</p>
              <h2 className="mt-4 max-w-xl font-display text-4xl font-bold leading-[1.03] tracking-[-.055em] sm:text-6xl">Make room for better sound.</h2>
              <p className="mt-5 max-w-md text-black/60">Save 30% on selected audio essentials until the signal fades.</p>
              <div className="mt-8 flex items-center gap-2 sm:gap-3" aria-label={`${hours} hours, ${minutes} minutes, ${seconds} seconds remaining`}>
                {[hours, minutes, seconds].map((time, i) => (
                  <div key={i} className="flex items-center gap-2 sm:gap-3">
                    <span className="grid size-14 place-items-center rounded-2xl bg-ink font-display text-xl font-bold text-white sm:size-16 sm:text-2xl">{time}</span>
                    {i < 2 && <span className="font-display text-xl font-bold">:</span>}
                  </div>
                ))}
              </div>
              <a href="#featured" className="button-primary mt-8">Shop flash sale <ArrowRight size={17} /></a>
            </div>
            <div className="relative mt-10 flex min-h-64 items-center justify-center lg:mt-0">
              <div className="absolute size-64 rounded-full border border-black/10 sm:size-80" />
              <div className="absolute size-48 rounded-full border border-black/10 sm:size-60" />
              <motion.img src="/products/arc-one.webp" alt="" animate={{ rotate: [0, 3, -2, 0], y: [0, -8, 0] }} transition={{ duration: 6, repeat: Infinity }} className="relative size-60 rounded-full object-cover shadow-2xl sm:size-72" />
              <span className="absolute right-[5%] top-[5%] grid size-20 rotate-12 place-items-center rounded-full bg-aether font-display text-lg font-bold text-white shadow-glow sm:size-24">−30%</span>
            </div>
          </motion.div>
        </section>

        <section id="why-aether" className="section-shell">
          <SectionHeading eyebrow="The Aether standard" title="Better, by design." />
          <div className="grid gap-px overflow-hidden rounded-[2rem] border border-black/5 bg-black/5 dark:border-white/10 dark:bg-white/10 md:grid-cols-2 lg:grid-cols-4">
            {[
              [PackageCheck, 'Curated, never crowded', 'Every object is tested for quality, utility, and staying power.'],
              [Globe2, 'Planet considered', 'Carbon-neutral delivery and lower-impact packaging, standard.'],
              [ShieldCheck, 'Two-year promise', 'Extra coverage on every product, with no hidden fine print.'],
              [Headphones, 'Human support', 'Real product experts, ready when you need a second opinion.'],
            ].map(([Icon, title, text], i) => (
              <motion.div {...reveal} transition={{ ...reveal.transition, delay: i * .08 }} key={title} className="bg-paper p-7 dark:bg-[#121317] sm:p-9">
                <div className="mb-10 grid size-11 place-items-center rounded-xl bg-black text-white dark:bg-white dark:text-black"><Icon size={20} /></div>
                <h3 className="font-display text-xl font-bold">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-black/55 dark:text-white/50">{text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="section-shell">
          <SectionHeading eyebrow="In good company" title="Loved in the real world." />
          <div className="grid gap-4 lg:grid-cols-3">
            {testimonials.map((item, i) => (
              <motion.figure {...reveal} transition={{ ...reveal.transition, delay: i * .1 }} key={item.name} className="flex min-h-80 flex-col justify-between rounded-[1.75rem] bg-white p-7 shadow-sm dark:bg-[#17181d] sm:p-9">
                <div>
                  <div className="mb-6 flex gap-1 text-aether">{[1,2,3,4,5].map((x) => <Star key={x} size={14} fill="currentColor" />)}</div>
                  <blockquote className="font-display text-xl font-semibold leading-relaxed tracking-tight">“{item.quote}”</blockquote>
                </div>
                <figcaption className="mt-8 flex items-center gap-3">
                  <span className="grid size-11 place-items-center rounded-full bg-[#e8e1ff] text-xs font-bold text-ink">{item.initials}</span>
                  <span><strong className="block text-sm">{item.name}</strong><span className="text-xs text-black/45 dark:text-white/45">{item.role}</span></span>
                </figcaption>
              </motion.figure>
            ))}
          </div>
        </section>

        {recent.length > 0 && (
          <section className="section-shell !pt-4">
            <SectionHeading eyebrow="Your trail" title="Recently viewed" />
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:max-w-4xl">
              {recent.map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} />)}
            </div>
          </section>
        )}

        <section className="section-shell">
          <motion.div {...reveal} className="relative overflow-hidden rounded-[2rem] bg-aether px-6 py-14 text-center text-white sm:px-12 sm:py-20">
            <div className="absolute -left-20 -top-24 size-72 rounded-full border-[50px] border-white/5" />
            <div className="absolute -bottom-40 -right-20 size-96 rounded-full border-[70px] border-white/5" />
            <p className="eyebrow text-white/60">Stay in the loop</p>
            <h2 className="relative mx-auto mt-4 max-w-2xl font-display text-4xl font-bold leading-tight tracking-[-.05em] sm:text-5xl">Good things, thoughtfully delivered.</h2>
            <p className="relative mx-auto mt-4 max-w-lg text-white/65">New arrivals, field notes, and members-only offers. Never noise.</p>
            {subscribed ? (
              <div role="status" className="relative mx-auto mt-8 flex max-w-md items-center justify-center gap-2 rounded-2xl bg-white px-5 py-4 font-semibold text-ink">
                <Check size={18} className="text-aether" /> You’re on the list.
              </div>
            ) : (
              <form onSubmit={(event) => { event.preventDefault(); setSubscribed(true) }} className="relative mx-auto mt-8 flex max-w-md flex-col gap-2 rounded-2xl bg-white p-2 sm:flex-row">
                <label htmlFor="email" className="sr-only">Email address</label>
                <input id="email" type="email" required autoComplete="email" placeholder="Email address" className="min-w-0 flex-1 bg-transparent px-4 py-3 text-sm text-ink outline-none placeholder:text-black/40" />
                <button className="button-primary justify-center whitespace-nowrap">Join the list <ArrowRight size={16} /></button>
              </form>
            )}
          </motion.div>
        </section>
      </main>

      <footer className="border-t border-black/10 px-4 pb-8 pt-14 dark:border-white/10 sm:px-6">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-10 pb-14 sm:grid-cols-2 lg:grid-cols-[1.7fr_1fr_1fr_1fr]">
            <div>
              <a href="#" className="font-display text-2xl font-extrabold tracking-[-.06em]">ÆTHER<span className="text-aether">.</span></a>
              <p className="mt-4 max-w-xs text-sm leading-relaxed text-black/50 dark:text-white/45">Remarkable technology for a more considered life.</p>
            </div>
            {[
              ['Shop', 'New arrivals', 'Audio', 'Wearables', 'Home'],
              ['About', 'Our story', 'Journal', 'Sustainability', 'Careers'],
              ['Help', 'Contact', 'Shipping', 'Returns', 'Warranty'],
            ].map(([title, ...links]) => (
              <div key={title}>
                <h3 className="mb-4 text-sm font-bold">{title}</h3>
                <div className="space-y-3">{links.map((link) => <a key={link} href="#" className="block text-sm text-black/50 transition hover:text-black dark:text-white/45 dark:hover:text-white">{link}</a>)}</div>
              </div>
            ))}
          </div>
          <div className="flex flex-col gap-4 border-t border-black/10 pt-6 text-xs text-black/40 dark:border-white/10 dark:text-white/35 sm:flex-row sm:items-center sm:justify-between">
            <p>© 2026 Aether Commerce. Made for what’s next.</p>
            <div className="flex gap-5"><a href="#">Privacy</a><a href="#">Terms</a><a href="#">Accessibility</a></div>
          </div>
        </div>
      </footer>

      <Assistant />
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="fixed bottom-6 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full bg-ink px-5 py-3 text-sm font-semibold text-white shadow-float dark:bg-white dark:text-ink">
            <Check size={16} /> {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
